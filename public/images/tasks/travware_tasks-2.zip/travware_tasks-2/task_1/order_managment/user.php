<?php

class user
{
    public $name;
    public $address;
    public $age;
    public $gender;
    public $image;

    public function notify($message){
        /**
         * TODO
         * we need to add channel to send notification to user but not now
         */
    }
}